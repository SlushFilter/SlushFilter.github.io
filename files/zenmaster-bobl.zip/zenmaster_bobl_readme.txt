"a mysterious force is controlling the water
journey through the ancient temple to find the source"

This is an enhanced difficulty hack created by noisepolice for the cult classic BÖBL by morphcat. This hack is meant to be played in ZEN MODE which can be toggled in the OPTIONS menu.

With this ROM file, you can become a Zenmaster in whatever way and on NES flash cart or emulator

note:
the mapper used has graphical issues with some flash carts like Everdrive N8

enormous thanks to morphcat games, who without none of this would be possible. In addition to creating the original game, they provided myself and some other modders with assets so that we could make these hacks. 

visit the morphcat itch.io https://morphcatgames.itch.io

join the morphcat Discord server: https://discord.gg/g2fdSwy

peep the official song https://youtu.be/IerHJyCc9kU

can you rescue the frogs?
