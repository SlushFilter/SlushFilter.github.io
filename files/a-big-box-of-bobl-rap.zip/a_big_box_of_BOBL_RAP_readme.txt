"xxx years beyond the events of BÖBL
our hero returns for another journey.
Adventure your way through the mystic temple
with the power of earth, water, and air."

this is an enhanced difficulty hack created by noisepolice for the cult classic BÖBL by morphcat

With this ROM file, you can play (a big box of) BÖBL RAP in whatever way and on
NES flash cart or emulator

note:
the mapper used has graphical issues with some flash carts

enormous thanks to morphcat games, who without none of this would be possible. In addition to creating the original game, they provided myself and some other modders with assets so that we could make these hacks. 

visit the morphcat itch.io https://morphcatgames.itch.io

join the morphcat Discord server: https://discord.gg/g2fdSwy

peep the official song https://youtu.be/IerHJyCc9kU
